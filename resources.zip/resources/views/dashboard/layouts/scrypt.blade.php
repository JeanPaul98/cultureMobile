  <!-- Vendor JS Files -->
  <script src="{{ asset('dashboard/vendor/apexcharts/apexcharts.min.js') }}"></script>
  <script src="{{ asset('dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
  <script src="{{ asset('dashboard/vendor/chart.js/chart.umd.js') }}"></script>
  <script src="{{ asset('dashboard/vendor/echarts/echarts.min.js') }}"></script>
  <script src="{{ asset('dashboard/vendor/quill/quill.min.js') }}"></script>
  <script src="{{ asset('dashboard/vendor/simple-datatables/simple-datatables.js') }}"></script>
  <script src="{{ asset('dashboard/vendor/tinymce/tinymce.min.js') }}"></script>
  <script src="{{ asset('dashboard/vendor/php-email-form/validate.js') }}"></script>

  <!-- Template Main JS File -->
  <script src="{{ asset('dashboard/js/main.js') }}"></script>