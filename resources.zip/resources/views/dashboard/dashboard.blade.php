<!DOCTYPE html>
<html lang="en">

<head>

@include('dashboard.layouts.link')

</head>
<body>

  @include('dashboard.layouts.header')

  @include('dashboard.layouts.sidebar')

  @section('content')

  @include('dashboard.layouts.footer')

  @include('dashboard.layouts.scrypt')

</body>

</html>