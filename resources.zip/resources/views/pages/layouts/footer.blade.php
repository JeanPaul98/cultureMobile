<footer style="margin-top: 100px;">  
    <div class="container clearfix">
      <p>© Culture Mobile 2023 | Restez connectés avec la communauté !
        <a href="https://www.facebook.com/pages/Accueil-Plus/1588172648114515?fref=ts">
          <img src="https://www.accueilplus.ca/wp-content/uploads/2015/06/icone_facebook_20px.png">
        </a>
      </p>
    </div>
</footer>
