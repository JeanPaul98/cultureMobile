
<script src="{{ asset('pages/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('pages/vendor/swiper/swiper-bundle.min.js') }}"></script>
<script src="{{ asset('pages/vendor/glightbox/js/glightbox.min.js') }}"></script>
<script src="{{ asset('pages/vendor/aos/aos.js') }}"></script>
<script src="{{ asset('pages/vendor/php-email-form/validate.js') }}"></script>

<!-- Template Main JS File -->
<script src="{{ asset('pages/js/main.js') }}"></script>